/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      animation: {
        'shine': 'shine 2s linear infinite',
        'borderShine': 'borderShine 2s ease-in-out infinite alternate',
        'borderShineGreen': 'borderShineGreen 2s ease-in-out infinite alternate',
      },
      keyframes: {
        shine: {
          '0%': { textShadow: '0 0 10px rgba(255, 215, 0, 0.5), 0 0 20px rgba(255, 215, 0, 0.3)' },
          '50%': { textShadow: '0 0 20px rgba(255, 215, 0, 0.8), 0 0 30px rgba(255, 215, 0, 0.5)' },
          '100%': { textShadow: '0 0 10px rgba(255, 215, 0, 0.5), 0 0 20px rgba(255, 215, 0, 0.3)' },
        },
        borderShine: {
          '0%': { boxShadow: '0 0 15px rgba(255, 215, 0, 0.4), inset 0 0 15px rgba(255, 215, 0, 0.2)' },
          '100%': { boxShadow: '0 0 25px rgba(255, 215, 0, 0.7), inset 0 0 25px rgba(255, 215, 0, 0.4)' },
        },
        borderShineGreen: {
          '0%': { boxShadow: '0 0 15px rgba(0, 255, 170, 0.4), inset 0 0 15px rgba(0, 255, 170, 0.2)' },
          '100%': { boxShadow: '0 0 25px rgba(0, 255, 170, 0.7), inset 0 0 25px rgba(0, 255, 170, 0.4)' },
        },
      },
    },
  },
  plugins: [],
} 