/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    appDir: true,
  },
  images: {
    domains: ['youtube.com', 'img.youtube.com'],
  },
  trailingSlash: true,
}

module.exports = nextConfig 